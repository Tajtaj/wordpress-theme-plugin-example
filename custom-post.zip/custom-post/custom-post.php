<?php
/*
Plugin Name: Custom post
Plugin URI: https://test.com
Description: Getting post data.
Author: Tajdar Khan Afridi
Author URI: http://test.com
Version: 1.0
*/


/**
* Blog listing page
*
*/

function custombloglisting(){
 global $post;
 $args = array( 
  'post_type' => 'post',
  'posts_per_page' => -1, 
 );
$postslist = new WP_Query( $args ); 
?>
<div class="custom-blog-container">
  <div class="row">
<?php
	if ($postslist->have_posts() ) {
      while ($postslist->have_posts() ){
      $postslist->the_post(); ?>
	    <div class="col-md-4 col-sm-6 blog-list">
			<div class="blog-wrapper">
				<div class="blo-desc">
				    <?php the_content(); ?>
				</div>
				<div class="blog-title"><h4 class="blog-titlle"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4></div>
			</div>
		</div>
  <?php
	  }
	  echo "</div>";
	}
	else{
    	echo "<p class='no-record-found'>No record found.</p>";
    }
	?>
	</div>
	<?php
}

add_shortcode('custombloglisting', 'custombloglisting');