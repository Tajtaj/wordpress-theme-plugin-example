<?php
/**
 * Template Name: Team
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 */

get_header(); ?>

<section class="main template team-main">
		<div class="container team-container">
			<div class="team-data col-xs-12">
				<div class="col-md-3 col-sm-6 col-xs-12 team-div">
					<h3>ARSH & KIRIN</h3>
					<p>Arsh and Kirin are the premier Make-up Artists at the Newlook Signature Salon. </p>
					<p>They are truly talented at their craft. Offering world-class makeup application to our clients that make each woman shine bright like a star.</p>
					<p>They both did their formal training at the highly renowned Makeup Institute in London. They have both trained at the highly renowned Makeup Institute in London.</p>
					<p> 
						Call us to book your next makeup Application 123 456 7890
					</p>
					<div class="specialized">
						<h5>SPECUALIZED MAKEUPS:</h5>
						<p>Party makeup Application</p>
						<p>Wedding Makeup Application -with Consultation</p>
						<p>Corporate Makeup Application</p>
					</div>
                </div>
                <div class="col-lg-5 col-md-6 col-sm-6 col-xs-12 team-div">
                	<div class="row">
                	<div class="col-md-6 team-image">
                	<img src="<?php bloginfo('template_url'); ?>/assets/images/arsh.png">
                	<h5>ARSH</h5>
                     </div>  
                     <div class="col-md-6 team-image">
                	<img src="<?php bloginfo('template_url'); ?>/assets/images/kirin.png">
                	<h5>KIRIN</h5>
                     </div>  
                 </div>
                </div>
			</div>
		</div>
	</section>

<?php get_footer();
