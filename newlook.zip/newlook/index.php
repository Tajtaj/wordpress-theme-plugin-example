<?php get_header(); ?> 
 <!-- inner section-->	
	<section class="main home-main" >
		<div id="myCarousel homeCarousel" class="carousel slide" data-ride="carousel">
			<!-- Carousel indicators -->
			<!-- Wrapper for carousel items -->
			<div class="carousel-inner homeCarousel-inner">
				<div class="item active">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/slide1.png" alt="First Slide">
				</div>
				<div class="item">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/slide2.png" alt="Second Slide">
				</div>
			</div>
			<!-- Carousel controls -->
		</div>
	</section>
	<!-- inner section End -->
<?php get_footer(); ?>