<?php
/**
 * Template Name: Contact
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 */

get_header(); ?>

<div class="wrap">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/page/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>

		</main><!-- #main -->
	</div><!-- #primary -->
</div><!-- .wrap -->
<section class="main template inner-main">
		<div id="myCarousel homeCarousel" class="carousel slide" data-ride="carousel">
			
			<div class="carousel-inner homeCarousel-inner">
				<div class="item active">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/slide1.png" alt="First Slide">
				</div>
				<div class="item">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/slide2.png" alt="Second Slide">
				</div>
			</div>

		</div>
		<div class="adbout-data inner-template">
			<?php
			while ( have_posts() ) : the_post();

				the_content();
				endwhile; // End of the loop.
			?>
		</div>
	</section>

<?php get_footer();
