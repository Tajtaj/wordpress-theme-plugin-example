<?php
/**
 * Template Name: Gallery
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 */

get_header(); ?>

	<!-- inner section-->	
	<section class="main template gallery-main">
		<div class="container-fluid gallery-container">
			<div class="col-md-4 col-md-offset-3 gallery-content">
				<h2>Gallery</h2>
				<p>Take a look at our photo gallery of our world class Make-up applications, hair updos and nail art.</p>

			</div>	
			<div class="col-md-12 gallery-slider">
			
						<div class="large-12 columns">
							<div class="owl-carousel owl-theme">
								<?php
								  $args = array( 'post_type' => 'n_gallery','posts_per_page'=> -1);
								  $postslist = get_posts( $args );
								  if($postslist){
								    foreach ( $postslist as $post ){
									  setup_postdata( $post );
								?>
								<div class="media">

									<div class="media-body">
										<div class="testimonial">
                                            <h5><?php the_title(); ?></h5>
											<?php 
											  if( have_rows('gallery_images') ){ 
											    while( have_rows('gallery_images') ){
												the_row();
												$image = get_sub_field('gallery_image');
											?>
											 <div class="col-xs-6 img-div"><img src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt'] ?>" /></div>
											<?php 
											  } 
											  }
                                            ?>
										</div>
									</div>
								</div>
								<?php
								}
			                    wp_reset_postdata();
			                   }
			                  ?>
								
                           </div>
						</div>
				
			</div>
		</div>	
	</section>
	<!-- inner section End -->
<script>
jQuery(document).ready(function() {
	var owl = jQuery('.owl-carousel');
	owl.owlCarousel({
		margin: 30,
		nav: true,
		loop: true,
		responsive: {
			0: {
				items: 1
			},
			600: {
				items: 1
			},
			1000: {
				items: 3
			}
		}
	})
})
</script>
<?php get_footer();
