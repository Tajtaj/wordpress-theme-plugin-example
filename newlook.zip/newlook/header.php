<!DOCTYPE html>
<html lang=<?php language_attributes(); ?>>
<head>
	<title>
	  <?php bloginfo('name'); ?> | <?php is_front_page() ? bloginfo('description') : wp_title(); ?>
	</title>
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<meta charset="<?php bloginfo('charset'); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/style.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/assets/css/owl.theme.default.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<?php wp_head(); ?>
</head>
<body>
	
    <!-- header start -->
	<header role="banner" id="header">
		<nav id="navbar-primary" class="navbar" role="navigation">
			<div class="container-fluid">
				<div class="navbar-header">
					<div class="col-xs-3 pull-right toogle-div">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-primary-collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<p class="hidden-sm hidden-md hidden-lg" >MENU</p>
					</div>
					<div class="col-xs-9 hidden-sm hidden-md hidden-lg timing-div">
						<p><i class="fa fa-clock-o"></i>Opening Times: Mon - Sun 11:00AM - 9:00PM</p>
						<p><i class="fa fa-phone"></i>Phone Number: 056 926 1122</p>
					</div>
				</div>
				<div class="collapse navbar-collapse" id="navbar-primary-collapse">
					<?php
						wp_nav_menu( array( 'theme_location' => 'main', 
						'menu_class' => 'nav navbar-nav', ) );

					 ?>
				</div>
			</div>
		</nav>
		<div class="header-bottom hidden-sm hidden-md hidden-lg">
			<div class="switcher-div text-right"><a href="javascript:void(0)">SWITCH TO ARABIC</a>
			</div>
			<div class="bottom-img text-center">
				<a href="home.html"><img id="bottom-logo" src="<?php bloginfo('template_url'); ?>/assets/images/logo.png" width="200" alt="Logo Thing main logo"></a>
			</div>
			<div class="bottom-phone">
				<span><i class="fa fa-phone"></i></span><span><p>Mobile / Whatsapp</p> <h5>04 327 989 </h5></span>
			</div>
			<div class="bottom-phone">
				<span><i class="fa fa-mobile"></i></span><span><p>Landline</p> <h5>+91 123 456 9890 / MAP </h5></span>
			</div>
			<div class="book-now text-center">
				<button class="btn btn-book">BOOK NOW</button>
			</div>
			<div class="footer-social bottom-socila">
					
					<a href="javascript:void(0)" class="fa fa-envelope-o"></a>
					<a href="javascript:void(0)" class="fa fa-facebook"></a>
					<a href="javascript:void(0)" class="fa fa-instagram"></a>
					<a href="javascript:void(0)" class="fa fa-twitter"></a>
				</div>
		</div>
	</header>
	<!-- header end -->