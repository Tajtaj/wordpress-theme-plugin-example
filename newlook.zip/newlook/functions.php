<?php

/**
* Register menus
*
*/
register_nav_menus( array(
	'top'    => __( 'Top Menu', 'newlook' ),
	'social' => __( 'Social Links Menu', 'newlook' ),
	'main' => __( 'Main Menu', 'newlook' ),
) );


/** 
* Register sidebars
*
*/
function wpb_init_widgets($id){

  register_sidebar(array(
    'name'  => 'Newsletter box',
    'id'    => 'newsletterbox',
    'before_widget' => '<div class="newsletter-box">',
    'after_widget'  => '</div>',
    'before_title'  => '<h5>',
    'after_title'   => '</h5>'
  ));
}

add_action('widgets_init', 'wpb_init_widgets');