<?php
/**
 * Template Name: About
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 */

get_header(); ?>

	<!-- inner section-->	
<section class="main template inner-main">
		<div id="myCarousel homeCarousel" class="carousel slide" data-ride="carousel">
			
			<div class="carousel-inner homeCarousel-inner">
				<div class="item active">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/slide1.png" alt="First Slide">
				</div>
				<div class="item">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/slide2.png" alt="Second Slide">
				</div>
			</div>

		</div>
		<div class="adbout-data inner-template">
			<p class="about-heading">THAT IS HOW I'VE ALWAYS DONE BUSINESS. <SPAN>I SEIZE THE MOMENT</SPAN>." MRS.AFZAL SAYS</p>
			<div class="about-desc">
				<p>Newlook  embodies  the  spirit  of  real  beauty  with  a  dynamic  hair  salon  and  elegant  beauty  lounge  that  focuses  on  superb  results,  positive  emotion  and  revitalizing  energy in  its  space.  With  the  latest  in  exciting  skin  therapies  and  hair  dynamics,  Newlook  primes  women  through  an  engaging  and  relaxing  experience  of  looking  your  best  and  feeling  fabulous. </p>

				
				<p id="knowmore-detail">
					30  years  ago,  the  journey  began  in  the  beauty  world  for  3  women  from  Canada.  Dubbed  as  a  ‘bionic  super  woman’ is  the  personality  who  conceived  the  Newlook  brand,  Musawar.  Always  known  to  bring  Newlook  steps  ahead  in  creative  innovation,  top  quality  service  and  versatile  dynamics  in  business,  she  has  brought  her  business  toan  inspiring  zenith.  Having  raised  her  daugh-ters  in  the  salon  game,  Arsh  &  Kirin  mirror  their  mothers  determined  persona  to  push  the  boundaries  of  norm  and  excel  in  giving  their  clients  ultimate  perfection  in  beauty  services.  <br> <br>

					Enriching  their  work  ethic  from  years  spent  in  Toronto,  the  sisters  are  bringing  their  expertise  inluxe  salon  experiences  to  the  UAE.  Having  selected  a  location  that  resonates  with  their  brand,  Newlook  is  going  to  find  its  new  home  in  the  heart  of  upcoming  trendy  spots.  In  a  city  with  top  tier  expectations,  Newlook  focuses  on  a  personalized  premium  salon  experience  with  an  energetic  team  primed  for  excellence. 
					


				</p>
				<a href="javascript:void(0)" class="read-all" id="readstory">Read our story</a>

			</div>
		</div>
</section>
	<!-- inner section End -->

<?php get_footer();
