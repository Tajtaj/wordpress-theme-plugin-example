<?php
/**
 * Template Name: Services
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 */

get_header(); ?>

<section class="template main">
	<div class="container-fluid salon-container">
		<div class="col-md-12 Services">
			<div class="col-md-12">
				<h1><?php the_title(); ?></h1>
			</div>
			
			<div class="salon-scroll col-md-12 none-padd">
				<?php
			  $args = array( 'post_type' => 'our_services','posts_per_page'=> -1);
			  $postslist = get_posts( $args );
			  if($postslist){
			  foreach ( $postslist as $post ){
			    setup_postdata( $post ); 

			  
			?> 
				<div class="col-md-2 col-sm-4 col-xs-12 salon-menudiv">
					<h5><?php the_title(); ?></h5>
					 <?php while(the_repeater_field('our_services_fields')): ?>
					<li>
						<a href="javascript:void(0)" class="pull-left">
							<?php the_sub_field('service_title'); ?></a>
						<span class="pull-right"><?php the_sub_field('service_price'); ?></span>
					</li>
					<?php endwhile; ?>
				</div>
				<?php
			  }
			  wp_reset_postdata();
			  }
			  ?>
			</div>
			
		</div>
	</div>
</section>

<?php get_footer();
