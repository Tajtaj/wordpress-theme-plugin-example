<?php
/**
 * Template Name: Institute
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 */

get_header(); ?>

<!-- inner section-->	
<section class="main template institute-main">
		<div class="container institute-container">
			<div class="institute-data col-xs-12">
				<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12 instituteimg-div">
				 	<div class="row">
				 		<div class="col-md-12 institute-image">
				 			<img src="<?php bloginfo('template_url'); ?>/assets/images/institute.png">
				 		</div>  
				 	</div>
                </div>
				<div class="col-lg-5 col-md-6 col-sm-6 col-xs-12 institutetext-div">
					<h3>INSTITUTE</h3>
					<p>
					We Offer Courses in Affliation With,</p>
					

						<ul>
							<li>Diploma in Beauty Therapy level 2.</li>
						<li>Diploma in Hair Dressing level 2.</li>

						<li>Certification in Make Up.</li>
						<li>Certification in Hair Cutting/Coloring.</li>
						<li>Certification in Skin Therapy.</li>
						<li>Certification in Nail Therapy.</li>
						<li>Advanced technical courses.</li>
						<li>Customized courses for students from abroad.</li>
					</ul>
					<a class="btn btn-send" href="/contact-us">BOOK YOUR SEAT</a>
					
                </div>
               
			</div>
		</div>
</section>
	<!-- inner section End -->
<?php get_footer();
