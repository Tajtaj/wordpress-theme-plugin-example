
	<footer>
		<div class="footer-content col-md-12 col-sm-12 none-padd">
				
			<div class="col-lg-2 col-md-3 col-sm-6 col-xs-12  pull-right">
				<div class="footer-logo">
					<img src="<?php bloginfo('template_url'); ?>/assets/images/footer-logo.png" class="center">
				</div>
				<div class="footer-social">
					<a href="javascript:void(0)" class="fa fa-phone"></a>
					<a href="javascript:void(0)" class="fa fa-envelope-o"></a>
					<a href="https://www.facebook.com/breathandhealth" class="fa fa-facebook" target="_blank"></a>
					<a href="https://www.instagram.com/BreathandHealth/" class="fa fa-instagram" target="_blank"></a>
					<a href="https://twitter.com/BreathandHealth" class="fa fa-twitter" target="_blank"></a>
				</div>
				<div class="email-div">
					
					
						<?php if(is_active_sidebar('newsletterbox')) : ?>
						<div class="input-group join-group">
                          <?php dynamic_sidebar('newsletterbox'); ?>
						</div>

                        <?php endif; ?>
				</div>
			</div>	
			<div class="col-lg-2 col-md-3 col-sm-6 col-xs-12 address-footer pull-right">
				<h4>NEWLOOK SIGNATURE SALON</h4>
				<h4>123 SHARJAH GROUND FLOOR SHARJAH, UAE</h4>
				<p class="black-text">+91 123 456 7890 <span>/</span> MAP</p>
				<h4>SERVICE / STYLISTS / PRESS $ EVENTS </h4><h4>MODELS WANTED / DIRECTIONS & HOURS</h4><h4> CONTACT</h4>
				<h5>&#169; 2018 NEWLOOK ALL RIGHTS RESERVED </h5>
			</div>
		</div>	
	</footer>
    <?php wp_footer(); ?>
	<script src="<?php bloginfo('template_url'); ?>/assets/js/jquery-3.2.1.min.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/assets/js/bootstrap.min.js"></script>
	<!-- <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>-->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/assets/js/owl.carousel.js"></script>
<script>
	jQuery(document).ready(function(){
		jQuery('#knowmore-detail').hide();
		
		

    	jQuery("#readstory").click(function(){
    		jQuery("#knowmore-detail").slideToggle();
			//jQuery('.read-all').addClass("changeColor");
			jQuery('.read-all').toggleClass("changeColor");
	    });
	});
</script>


</body>
</html>